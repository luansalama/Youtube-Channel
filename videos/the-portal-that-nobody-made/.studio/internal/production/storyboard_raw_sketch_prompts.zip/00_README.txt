STORYBOARD CONTENT-GATED PROMPTS — VERSION 3

This package contains 49 standalone GPT Image prompts, one per storyboard panel.

WHAT CHANGED
• Every prompt begins with a high-priority content gate.
• Each prompt explicitly states what may appear and what must not appear.
• The global style lock is identical in all 49 prompts and contains no story-specific objects or characters.
• Character, prop and environmental appearance notes are included only when that item is authorised to be visible.
• Future or previous story elements are not described as general continuity context.
• Multi-beat panels explicitly declare their internal layout.
• All outputs remain raw monochrome graphite storyboard sketches on warm-white paper.

HOW TO USE
1. Generate one prompt at a time.
2. Use the first approved result as the style reference for later generations.
3. Tell the image model that the reference controls only pencil medium and finish—not scene content.
4. Reject any result containing an item listed under FORBIDDEN IN THIS IMAGE.
5. Verify the FINAL CHECK before accepting the panel.

Important: no images were generated while preparing this package.
